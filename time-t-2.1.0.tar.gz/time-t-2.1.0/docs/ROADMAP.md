# Time-T — Roadmap

Versioning follows master prompt §37. Status reflects reality as of this
commit, verified by the test suite (`pytest -q`) — see TESTING.md for how to
reproduce every claim below.

## Milestone 0 — Architecture ✅ DONE
- ARCHITECTURE.md, LANGUAGE.md, ROADMAP.md, TESTING.md, DESIGN_DECISIONS.md
  written before substantial implementation, per §4.
- 11 architectural risks + mitigations recorded (ARCHITECTURE.md §11).

## Milestone 1 — Lexer + parser + minimal language ✅ DONE
- `timet/lexer.py`, `timet/parser.py`, `timet/ast_nodes.py`.
- Tests: `tests/test_lexer.py`, `tests/test_parser.py`.
- Fuzz: `tests/test_fuzz.py` (random byte streams + mutated valid programs
  must never crash the process — only raise `LexError`/`ParseError`).

## Milestone 2 — Types + functions + modules ✅ DONE (v0.3.0)
- DONE: primitive types, function declarations, closures, type checking,
  scoping, immutable/mutable bindings (`let`/`var`), `break`/`continue`
  with static out-of-loop rejection (E0215, v0.4.0), true-division typing
  (`/` always Float, soundness fix DD-16), diagnostics with
  location + expected/actual (`timet/diagnostics.py`); file modules
  (`import a.b.c [as m]`, typed exports, import-once, fresh scope —
  DD-13, `timet/modules.py`).
- NOT DONE (tracked, not silently skipped): generics, traits/interfaces,
  structs, enums, pattern matching, static shape types.
- Tests: `tests/test_typechecker.py`, `tests/test_modules.py`.

## Milestone 3 — Executable runtime ✅ DONE (interpreter)
- `timet/interpreter.py` tree-walking evaluator executes typed AST: `let`,
  `var`, `fn`, closures, `if`/`while`, arithmetic, comparisons, `print`.
- Tests: `tests/test_interpreter.py`, `tests/test_examples.py` (example
  programs run end-to-end and their stdout is checked byte-for-byte against
  `examples/*.expected`).

## Milestone 4 — Arrays / tensors ✅ DONE (CPU, NumPy-backed)
- `timet/tensor.py`: construction, dtype, shape, broadcasting, matmul,
  reshape/transpose/permute, reductions (sum/mean/max/min), elementwise
  math (exp/log/sqrt), activations (relu/sigmoid/tanh/softmax), basic
  indexing/slicing.
- Tests: `tests/test_tensor.py`, including differential tests against
  NumPy's own reference operations (§29) with documented tolerances
  (`tests/numerics.py`, DD-7).

## Milestone 5 — Autodiff ✅ DONE (reverse-mode, dynamic tape)
- `timet/autodiff.py`, `timet/tensor.py` backward rules for every
  implemented op.
- Tests: `tests/test_autodiff.py` — every backward rule is checked against
  finite differences (central difference, h=1e-4) and reports max
  abs/rel error on failure, never a bare assert (§18, §29).
- Worked example from the master prompt itself is a literal regression
  test: `x=[1,2,3]` grad, `y=sum(x*x)`, backward → `grad == [2,4,6]`.

## Milestone 6 — IR + optimization ✅ DONE (v0.2.0; hard limits documented)
- DONE (v0.1.0): `timet/ir.py` typed IR, lowering from typed AST, JSON
  serialization, `time-t inspect --ir`.
- DONE (v0.2.0):
  - The IR is **executable**: `timet/ir_exec.py` runs IR directly
    (structured block-tree walk; `var`s via named storage frames, `let`s as
    SSA temps). CLI: `time-t run <file> --via-ir [-O 0|1]`.
  - The IR is **optimizable**: `timet/optimize.py` implements constant
    folding, type-aware algebraic simplification, segment-local CSE and
    copy propagation, and DCE — all documented with their exact safety
    rules in DD-12 (e.g. `x*0` is never folded: NaN/Inf; `1/0` stays a
    runtime error).
  - Lowering extended: while-conditions live inside the loop region,
    for-loops, `no_grad` regions, kwargs, dynamic calls, and top-level
    statements (a synthetic `__main__` function).
  - **Differentially verified**: AST interpreter vs IR-O0 vs IR-O1 must
    produce byte-identical stdout on every example program AND on
    generated random programs (`tests/test_ir_exec_diff.py`). This gate has
    already caught real bugs (CSE leaving a `return` arg dangling;
    an eliminated temp still referenced by a call) -- both pinned as
    regression tests. gate: DD-14.
- DELIBERATE LIMITS (executor fails loudly, never guesses): lambdas,
  nested `fn` decls, if-expressions are not lowered; `&&`/`||` are eager in
  IR; no inlining/fusion/LICM (needs dataflow/CFG — DD-9, DD-12).
- Tests: `tests/test_ir.py`, `tests/test_ir_exec.py`,
  `tests/test_optimize.py`, `tests/test_ir_exec_diff.py`.

## Milestone 7 — Neural-network framework 🟡 PARTIAL (expanded v0.2.0)
- DONE: `timet/nn.py` — layers `Linear`, `ReLU`, `Sigmoid`, `Tanh`,
  `Softmax`, `Flatten`, `Dropout` (inverted, seeded = deterministic,
  train/eval aware), `Sequential`; losses `MSELoss`, `CrossEntropyLoss`
  (log-softmax + one-hot NLL, gradient finite-difference checked),
  `BCELoss`; `Module.train()/eval()` recursion; functional conveniences
  (`nn.cross_entropy_loss`, ...). `timet/optim.py` — `SGD`, `Adam` (with
  bias correction; Adam convergence is asserted by a test that must reach
  a loss threshold on XOR, with the measured value printed).
- DONE (v0.2.0): the library is reachable FROM TIME-T CODE via the
  pre-bound `nn`/`optim`/`train` globals (DD-10's documented bridge until a
  real module system exists) — `examples/07_xor_classifier.tt` trains a
  2-8-2 MLP+Adam+cross-entropy classifier to 100% XOR accuracy and runs
  byte-identically on all three execution engines.
- EXPANDED (v0.5.0, DD-17): `Conv2D` layer + `conv2d` functional op
  (NCHW, stride + zero-padding; im2col forward with hand-written col2im
  backward, finite-difference checked from x/weight/bias in three
  stride/padding configs); `Embedding` (scatter-add gradient, duplicate
  indices accumulate -- pinned); `optim.AdamW` (decoupled weight decay,
  bit-identical to Adam at wd=0). Usable from Time-T code:
  `examples/09_conv_center_detector.tt` trains a Conv2D+Flatten+Linear
  center-detector on all three engines (loss ~1e-7, byte identical).
- EXPANDED (v0.9.1, DD-22): `LayerNorm` (Ba, Kiros, Hinton 2016) layer
  and `layer_norm` functional op with learnable elementwise affine scale
  and bias (or affine disabled), numerical stability epsilon, gradient
  finite-difference checked across input, weight, and bias, plus checkpoint
  round-trip. Usable from Time-T code: `examples/11_layernorm_mlp.tt`
  trains an MLP with LayerNorm on all three engines with byte-identical
  output.
- EXPANDED (v0.10.0, DD-23): `MultiheadAttention`, `TransformerBlock`,
  and `GELU` (Milestone 7: attention and transformer architecture).
  Multi-head attention with Q/K/V projections and scaled dot-product attention
  (supports self-attention, cross-attention, and additive attention masks),
  GELU activation with analytic gradient checking, Pre-LN Transformer Encoder
  Block with residual connections and checkpoint round-trip. Usable from
  Time-T code: `examples/12_transformer_block.tt` trains a TransformerBlock
  on all three engines (AST, IR-O0, IR-O1) with byte-identical output.
- EXPANDED (v0.11.0, DD-24): `Conv1D` layer + `conv1d` functional op
  (NCL, stride + zero-padding; im2col forward with hand-written col2im
  backward, finite-difference checked from x/weight/bias across multiple
  stride/padding configurations). Checkpoint serialization verified.
  Usable from Time-T code: `examples/13_conv1d_classifier.tt` trains a
  Conv1D sequence classifier on all three engines with byte-identical output.
- EXPANDED (v0.12.0, DD-25): `RMSNorm` (Root Mean Square Layer Normalization)
  and `TransformerLM` (complete decoder-only causal language model combining
  token embedding, learned positional embedding, transformer blocks, norm,
  and LM head for autoregressive sequence modeling). Multi-dimensional
  CrossEntropyLoss support `(*, C)`. Checkpoint serialization verified.
  Usable from Time-T code: `examples/14_transformer_lm.tt` trains a
  TransformerLM next-token predictor on all three engines (AST, IR-O0, IR-O1)
  with byte-identical output.
- NOT DONE: Conv3D, BatchNorm,
  weight/init schemes beyond Kaiming-uniform, mixed precision.





## Milestone 8 — Training 🟡 PARTIAL (started v0.2.0)
- DONE: `timet/train.py` — `accuracy()` metric, `History`,
  `fit()` (full-batch loop: forward → backward → step → zero_grad, logging
  + pluggable metrics) and `EarlyStopping`. `timet/checkpoint.py` —
  save/load/resume of parameters as deterministic, versioned JSON
  (DD-11); resume correctness is proven by the train-20/save/restore/
  train-30 == uninterrupted-train-50 test.
- EXPANDED (v0.6.0, DD-18): `TensorDataset` + `DataLoader` (mini-batching;
  seeded deterministic shuffling with no global-RNG touching; partial
  final batch yielded by default, drop_last explicit), `fit_loader()`
  (mean-of-batches epoch metrics, scheduler stepped once per epoch --
  both pinned by tests) and `StepLR`/`ExponentialLR`/`CosineAnnealingLR`
  (recomputed-from-base exactness). Reachable from Time-T code (example
  10: mini-batch training with LR decay, byte-identical on all engines).
- EXPANDED (v0.7.0, DD-19): validation splits -- `fit_loader(val_loader=...)`
  with per-epoch `history.val_losses`, enforced eval-mode discipline for
  the val pass (mode restored; probe-pinned), and `EarlyStopping` monitor
  selection ('loss'/'val_loss'/metric, E0643 on monitor-without-data,
  never silent fallback). Train/val phases share ONE `_run_epoch` loop.
- EXPANDED (v0.8.0, DD-20): binary checkpoint format v2 (`.ttck`:
  deterministic zip of manifest + raw f32 .npy entries, byte-identical
  saves, content-sniffed loading of both v1/v2, manifest-integrity
  errors E0645--E0648). Resume theorem re-proven for v2 WITH PLAIN SGD
  only -- Adam's moments aren't checkpointed by either format, and an
  Adam version of the theorem was falsified while testing (DD-20).
- EXPANDED (v0.9.0, DD-21): `save_state`/`load_state` training-state
  checkpoints (optimizer moments by param position, scheduler internals,
  epoch counter, DataLoader RNG streams). The Adam-resume theorem that
  DD-20 FALSIFIED for param-only checkpoints now holds BYTE-EXACTLY and
  is the headline test; half-restored resumes are refused loudly
  (E0649--E0658), never silent.
- NOT DONE: training-run log format, dtype-faithful binary storage
  (>f32), History serialization, distributed anything.

## Milestone 9 — Native optimization 🟡 PARTIAL (started v0.4.0)
- DONE (v0.4.0): a working native path — `timet/native.py` C-emitter over
  a strict, byte-verified subset (DD-15; scalars/control flow/typed
  functions/recursion/print of Int-Bool-String), CLI `build` (upgraded
  from stub to real) and `run --native`; gcc compile ~50 ms for small
  programs; `benchmarks/run_benchmarks.py` records the measured
  ~3000x scalar-loop interpreter-overhead removal (caveat-recorded; tensor
  workloads are NumPy-bound either way and see no such ratio).
- NOT DONE (tracked): tensors in the native backend, Float printing
  (shortest-repr formatting parity), `for` loops natively, f-strings and
  string concat natively, modules natively, whole-program optimization
  (inlining, const-prop across functions — needs CFG/dataflow, DD-12),
  loop optimizations, backend kernel selection, multi-objective
  optimization, LLVM-vs-C re-targeting decision (deliberately deferred,
  DD-15 explains why C-first keeps that door open).

## Milestone 10 — ARM64 / mobile ✅ DONE (v1.0.0, DD-27)
- INT8 dynamic post-training quantization (`timet.mobile.quantize_dynamic`,
  `timet.mobile.quantize_linear`, `timet.mobile.dequantize_linear`) delivering
  4x parameter memory reduction.
- `QuantizedLinear` layer executing integer matrix multiplication (int32 accumulation)
  with dynamic activation scale conversion.
- Standalone mobile deployment package format (`.ttm` / `.ttpack`) via
  `package_mobile` and zero-dependency `load_mobile` runner.
- CLI subcommand `time-t package <model> -o <path.ttm>` supporting automatic
  INT8 dynamic quantization for edge / mobile deployment.
- Time-T code reachable via pre-bound `mobile` module; demonstrated in
  `examples/15_mobile_inference.tt` running byte-identically on AST, IR-O0,
  and IR-O1 engines.
- Tests: `tests/test_mobile.py` (7 tests covering symmetric/asymmetric
  quantization, QuantizedLinear, Sequential conversion, and mobile package I/O).

## Milestone 11 — Interoperability ✅ DONE (v0.13.0, DD-26)
- Model & tensor export to industry-standard HuggingFace `safetensors` format
  via `checkpoint.save_safetensors` and `checkpoint.load_safetensors`.
- NumPy `.npz` archive export/import via `checkpoint.save_npz` and `checkpoint.load_npz`.
- Format-agnostic checkpoint loader: `checkpoint.load` auto-detects `.safetensors`,
  `.npz`, binary `.ttck`, and JSON checkpoints via content-sniffing.
- CLI subcommand `time-t export <file> -o <output> [-f format] [--json]` fully
  functional with diagnostic reporting (`E0800`, `E0801`).
- Tests: `tests/test_interop.py` (round-trip verification, CLI invocation, error handling).

## Milestone 12 — Stable release ✅ DONE (v1.0.0, DD-28)
- Complete language and runtime specification with all 11 foundational CLI commands
  fully implemented (`check`, `run`, `inspect`, `test`, `bench`, `repl`, `build`,
  `export`, `package`, `doctor`, `profile`) without placeholders or stubs.
- 15 end-to-end runnable example programs spanning basic calculations, neural networks,
  convolutions, transformers, causal language modeling, and quantized mobile inference.
- Multi-engine differential execution verified across AST interpreter, IR-O0, and IR-O1.
- Strict diagnostic error reporting throughout the compiler and runtime.
- Semantic Version 1.0.0 specification milestone achieved.


---

## Benchmarks status (§19)
`benchmarks/run_benchmarks.py` measures, on **this sandbox's actual CPU**
(labelled in the output JSON with `platform.processor()`/`platform.uname()`),
wall-clock time and throughput for: scalar add loop, vector add, matmul at a
few sizes, a tensor reduction, and one autodiff backward pass. Raw results
are written to `benchmarks/results/*.json` with a timestamp and are
regenerated by running the script — no numbers in documentation are
hand-typed or estimated.

## Model-scale status (§16)
Only capability **A (can be represented)** and **C (can run inference)** have
been exercised, and only at the smallest scales (≤ a few thousand
parameters, e.g. the XOR MLP and linear-regression examples) — this is a
tree-walking Python interpreter; no claim is made about 1M+ parameter
training throughput because it has not been measured. This will be updated
only after real measurements are taken at larger scale.

## Self-Criticism
Milestone retrospectives (master prompt §39, all 10 questions) live in
docs/RETROSPECTIVES.md — one dated entry per milestone band, kept as history.
